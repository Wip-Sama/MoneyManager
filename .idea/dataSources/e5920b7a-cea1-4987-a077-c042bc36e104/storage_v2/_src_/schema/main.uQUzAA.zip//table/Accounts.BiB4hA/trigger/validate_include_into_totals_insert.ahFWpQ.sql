CREATE TRIGGER validate_include_into_totals_insert
BEFORE INSERT ON Accounts
FOR EACH ROW
BEGIN
    SELECT RAISE(ABORT, 'include_into_totals must be 0 or 1')
    WHERE NEW.include_into_totals NOT IN (0, 1);
END;

